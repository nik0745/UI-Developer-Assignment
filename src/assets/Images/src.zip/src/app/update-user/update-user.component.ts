import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent {
  Image = '/assets/Images/back.jpeg';
  url = '/assets/Images/1.png';

  id: any;
  userData: any;
  countries = [
    { name: 'India', states: ['Gujarat', 'Rajasthan', 'Maharashtra', 'Delhi', 'Tamil Nadu'] },
    { name: 'USA', states: ['California', 'Texas', 'New York', 'Colorado', 'Indiana'] },
    { name: 'UK', states: ['England', 'Scotland', 'Wales', 'Northem Ireland'] },
    { name: 'AUSTRALIA', states: ['Hokkaido', 'Chibe', 'Fukui', 'Gunma'] },
    { name: 'JAPAN', states: ['Victoria', 'Queensland', 'Tasmania', 'South Wales', 'Western Australia', 'South Australia'] }
  ];
  states: string[] = [];

  updateForm = new FormGroup({
    id: new FormControl(''),
    userimage: new FormControl(null),
    firstname: new FormControl('', [Validators.required]),
    lastname: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]),
    contacts: new FormControl('', [Validators.required]),
    age: new FormControl('', [Validators.required, Validators.min(18), Validators.max(100)]),
    country: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    tags: new FormControl('', [Validators.required]),
  });

  constructor(private route: ActivatedRoute, private user: DataService, private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get("id")
    this.user.getUserById(this.id).subscribe(data => {
      this.userData = data;
      this.updateForm.patchValue(this.userData); // Populate form with existing user data
      this.onCountryChange(); // Populate states based on selected country
    })
  }

  onUpdate() {
    if (this.updateForm.valid) {
      const updateData = {
        id: this.updateForm.value.id,
        firstname: this.updateForm.value.firstname,
        lastname: this.updateForm.value.lastname,
        email: this.updateForm.value.email,
        contacts: this.updateForm.value.contacts,
        age: this.updateForm.value.age,
        country: this.updateForm.value.country,
        state: this.updateForm.value.state,
       
        tags: this.updateForm.value.tags
      };

      this.user.updateDetail(this.id, updateData).subscribe((data) => {
        console.log(data);
        alert('Record updated successfully');
        this.router.navigate(['/profile']);
      }, (err) => {
        console.log("Error updating data", err);
      });
    }
  }


  onCountryChange(): void {
    const selectedCountry = this.updateForm.get('country')?.value;
    const country = this.countries.find(c => c.name === selectedCountry);
    if (country) {
      this.states = country.states;
      this.updateForm.patchValue({ state: '' }); // Reset selected state
    }
  }

  onSelectFile(e: any) {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
        this.updateForm.patchValue({ userimage: event.target.result });
      }
    }
  }
  
}