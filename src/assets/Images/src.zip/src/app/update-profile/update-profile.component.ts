import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent {

  Image = '/assets/Images/back.jpeg';
  url = '/assets/Images/1.png';

  id: any;
  userData: any;

  updateForm = new FormGroup({
    id: new FormControl(''),
    userimage: new FormControl(null),

  });

  constructor(private route: ActivatedRoute, private user: DataService, private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get("id")
    this.user.getUserById(this.id).subscribe(data => {
      this.userData = data;
      this.url = this.userData.userimage; // Update image URL

    })
  }

  onUpdate() {
    if (this.updateForm.valid) {
      const updateData = {
        id: this.updateForm.value.id,
        userimage: this.url,

      };

      this.user.updateDetail(this.id, updateData).subscribe((data) => {
        console.log(data);
        alert('Record updated successfully');
        this.router.navigate(['/profile']);
      }, (err) => {
        console.log("Error occurs, updating data", err);
      });
    }
  }

  onSelectFile(e: any) {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
        this.updateForm.patchValue({ userimage: event.target.result });
      }
    }
  }
}
